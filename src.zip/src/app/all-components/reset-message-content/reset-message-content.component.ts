import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-message-content',
  templateUrl: './reset-message-content.component.html',
  styleUrls: ['./reset-message-content.component.scss'],
})
export class ResetMessageContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
