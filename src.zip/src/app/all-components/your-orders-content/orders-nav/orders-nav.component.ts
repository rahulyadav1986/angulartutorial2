import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-nav',
  templateUrl: './orders-nav.component.html',
  styleUrls: ['./orders-nav.component.scss'],
})
export class OrdersNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
