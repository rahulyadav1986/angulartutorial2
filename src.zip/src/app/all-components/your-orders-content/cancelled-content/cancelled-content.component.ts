import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancelled-content',
  templateUrl: './cancelled-content.component.html',
  styleUrls: ['./cancelled-content.component.scss'],
})
export class CancelledContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
