import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-ledger-content',
  templateUrl: './general-ledger-content.component.html',
  styleUrls: ['./general-ledger-content.component.scss'],
})
export class GeneralLedgerContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
