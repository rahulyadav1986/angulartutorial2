import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-finance-content',
  templateUrl: './your-finance-content.component.html',
  styleUrls: ['./your-finance-content.component.scss'],
})
export class YourFinanceContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
