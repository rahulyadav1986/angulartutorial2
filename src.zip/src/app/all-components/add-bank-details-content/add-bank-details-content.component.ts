import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bank-details-content',
  templateUrl: './add-bank-details-content.component.html',
  styleUrls: ['./add-bank-details-content.component.scss'],
})
export class AddBankDetailsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
