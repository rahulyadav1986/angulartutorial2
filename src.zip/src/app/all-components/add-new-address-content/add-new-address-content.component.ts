import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-address-content',
  templateUrl: './add-new-address-content.component.html',
  styleUrls: ['./add-new-address-content.component.scss'],
})
export class AddNewAddressContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
