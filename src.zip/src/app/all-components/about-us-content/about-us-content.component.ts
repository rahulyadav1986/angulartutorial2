import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-us-content',
  templateUrl: './about-us-content.component.html',
  styleUrls: ['./about-us-content.component.scss'],
})
export class AboutUsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
