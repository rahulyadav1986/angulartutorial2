import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-social',
  templateUrl: './menu-social.component.html',
  styleUrls: ['./menu-social.component.scss'],
})
export class MenuSocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
