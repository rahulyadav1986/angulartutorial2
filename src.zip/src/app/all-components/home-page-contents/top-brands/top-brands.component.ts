import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-brands',
  templateUrl: './top-brands.component.html',
  styleUrls: ['./top-brands.component.scss'],
})
export class TopBrandsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
