import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-center-purchase-content',
  templateUrl: './help-center-purchase-content.component.html',
  styleUrls: ['./help-center-purchase-content.component.scss'],
})
export class HelpCenterPurchaseContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
