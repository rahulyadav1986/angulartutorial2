import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-category-contents',
  templateUrl: './sub-category-contents.component.html',
  styleUrls: ['./sub-category-contents.component.scss'],
})
export class SubCategoryContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
