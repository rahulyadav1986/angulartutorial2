import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-address-content',
  templateUrl: './select-address-content.component.html',
  styleUrls: ['./select-address-content.component.scss'],
})
export class SelectAddressContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
