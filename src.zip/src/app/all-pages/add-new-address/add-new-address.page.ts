import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-address',
  templateUrl: './add-new-address.page.html',
  styleUrls: ['./add-new-address.page.scss'],
})
export class AddNewAddressPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
