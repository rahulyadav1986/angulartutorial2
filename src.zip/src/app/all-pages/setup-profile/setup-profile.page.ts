import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-profile',
  templateUrl: './setup-profile.page.html',
  styleUrls: ['./setup-profile.page.scss'],
})
export class SetupProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
