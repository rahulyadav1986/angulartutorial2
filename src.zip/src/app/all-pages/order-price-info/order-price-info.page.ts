import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-price-info',
  templateUrl: './order-price-info.page.html',
  styleUrls: ['./order-price-info.page.scss'],
})
export class OrderPriceInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
