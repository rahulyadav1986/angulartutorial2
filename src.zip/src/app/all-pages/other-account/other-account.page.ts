import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-account',
  templateUrl: './other-account.page.html',
  styleUrls: ['./other-account.page.scss'],
})
export class OtherAccountPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
