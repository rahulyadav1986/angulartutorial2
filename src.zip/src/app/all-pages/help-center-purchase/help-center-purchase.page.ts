import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-center-purchase',
  templateUrl: './help-center-purchase.page.html',
  styleUrls: ['./help-center-purchase.page.scss'],
})
export class HelpCenterPurchasePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
