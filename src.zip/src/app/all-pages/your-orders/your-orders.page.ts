import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-orders',
  templateUrl: './your-orders.page.html',
  styleUrls: ['./your-orders.page.scss'],
})
export class YourOrdersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
