import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-item-price-info',
  templateUrl: './item-price-info.page.html',
  styleUrls: ['./item-price-info.page.scss'],
})
export class ItemPriceInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  

}
