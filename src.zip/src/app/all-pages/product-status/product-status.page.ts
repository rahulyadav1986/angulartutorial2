import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-status',
  templateUrl: './product-status.page.html',
  styleUrls: ['./product-status.page.scss'],
})
export class ProductStatusPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
