import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-month',
  templateUrl: './change-month.page.html',
  styleUrls: ['./change-month.page.scss'],
})
export class ChangeMonthPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
