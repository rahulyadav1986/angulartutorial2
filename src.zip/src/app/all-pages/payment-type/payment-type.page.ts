import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-type',
  templateUrl: './payment-type.page.html',
  styleUrls: ['./payment-type.page.scss'],
})
export class PaymentTypePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
